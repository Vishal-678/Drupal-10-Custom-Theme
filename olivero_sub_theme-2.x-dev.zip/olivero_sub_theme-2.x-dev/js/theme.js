/**
 * @file
 * my_sub_theme behaviors.
 */

(function ($, Drupal) {
  "use strict";

  /**
   * Behavior description.
   */
  Drupal.behaviors.oliveroSubTheme = {
    attach: function (context, settings) {
      // My custom js.
    },
  };
})(jQuery, Drupal);
